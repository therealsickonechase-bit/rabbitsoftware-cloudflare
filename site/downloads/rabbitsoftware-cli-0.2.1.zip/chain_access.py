"""Read-only source selection. Account credentials never enter UI or provider requests."""

import base64
import hashlib
import json
import os
import re
import time
from dataclasses import dataclass
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import HTTPRedirectHandler, Request, build_opener

from rabbit import ChainError, DEMO_PATH, MAX_BYTES, load_chain

API = "https://api.rabbitsoftware.io"
CONFIG = Path.home() / ".rabbitsoftware" / "connection.json"


@dataclass
class Source:
    entries: list[dict[str, str]]
    label: str
    demo: bool = False


class NoRedirects(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ChainError("Sync redirect refused; credentials were not forwarded.")


def decode(raw: bytes) -> object:
    if len(raw) > MAX_BYTES:
        raise ChainError("Source exceeds the 1 MiB limit.")
    try:
        return json.loads(raw.decode("utf-8-sig"))
    except (ValueError, UnicodeError, RecursionError) as error:
        raise ChainError("Source is not valid bounded JSON.") from error


def read_json(path: Path) -> object:
    with path.open("rb") as file:
        return decode(file.read(MAX_BYTES + 1))


def fetch(path: str, headers: dict[str, str] | None = None) -> bytes:
    if not path.startswith("/v1/"):
        raise ChainError("Only documented sync API paths are supported.")
    try:
        with build_opener(NoRedirects).open(
            Request(API + path, headers={"Accept": "application/json",
                                        "User-Agent": "RabbitSoftware-ReadOnly/0.2 (+https://rabbitsoftware.io/cli)",
                                        **(headers or {})}),
            timeout=20,
        ) as response:
            raw = response.read(MAX_BYTES + 1)
    except HTTPError as error:
        guidance = ("Check device registration, source name, or clock." if headers else
                    "Public API access failed; try later or use the website corpus viewer.")
        raise ChainError(f"Sync returned HTTP {error.code}. {guidance}") from error
    except (URLError, OSError) as error:
        raise ChainError("Sync could not be reached. Check your connection; no automatic retry was made.") from error
    if len(raw) > MAX_BYTES:
        raise ChainError("Sync source exceeds the 1 MiB limit.")
    return raw


def display_json(value: object) -> str:
    text = json.dumps(value, ensure_ascii=True, sort_keys=True)
    if len(text) > 32000:
        raise ChainError("An entry exceeds the 32,000-character display limit.")
    return text


def text(value: object, field: str) -> str:
    if not isinstance(value, str) or not value.strip() or len(value) > 2000:
        raise ChainError(f"Invalid {field} text.")
    if any(ord(char) < 32 or ord(char) == 127 for char in value):
        raise ChainError(f"Control characters in {field}.")
    return value


def adapt(data: object) -> Source:
    if not isinstance(data, dict):
        raise ChainError("Expected a documented chain or snapshot object.")
    if data.get("schema") == "rabbitsoftware.local-public-lookup.v1":
        raise ChainError("Use load_source for local lookup files.")
    kind = "research" if "events" in data else "maxwell" if "chain" in data else "dna"
    if kind in {"research", "maxwell"}:
        field = "events" if kind == "research" else "chain"
        if set(data) != {"schema_version", "classification", field} or type(data["schema_version"]) is not int \
                or data["schema_version"] != 1 or data["classification"] != "public":
            raise ChainError("Expected an explicitly public v1 archive.")
    else:
        field = "entries"
        if set(data) != {"name", "account", "entries"}:
            raise ChainError("Unsupported chain format; no data was imported.")
        text(data["name"], "chain name")
    records = data[field]
    if not isinstance(records, list) or not 1 <= len(records) <= 1000:
        raise ChainError("Source needs 1-1000 entries.")
    entries, seen = [], set()
    previous = "0" * 64 if kind == "maxwell" else "0x0"
    for index, record in enumerate(records):
        if not isinstance(record, dict):
            raise ChainError("Invalid archive entry.")
        if kind == "research":
            identifier = record.get("event_id")
            if not isinstance(identifier, str) or not re.fullmatch(r"[0-9a-f]{32}", identifier) \
                    or record.get("classification") != "public" or type(record.get("schema_version")) is not int \
                    or record.get("schema_version") != 1:
                raise ChainError("Invalid public research event.")
            topic = text(record.get("event_type") or record.get("backend"), "event type")
            classification, payload = "public", record
        else:
            number_field = "block_number" if kind == "maxwell" else "index"
            digest = record.get("hash")
            pattern = r"[0-9a-f]{64}" if kind == "maxwell" else r"0x[0-9a-f]{64}"
            if type(record.get(number_field)) is not int or record[number_field] != index \
                    or not isinstance(digest, str) or not re.fullmatch(pattern, digest) \
                    or record.get("previous_hash") != previous:
                raise ChainError("Invalid chain ordering or previous-hash linkage.")
            previous, identifier = digest, digest
            payload = record.get("data" if kind == "maxwell" else "record")
            if not isinstance(payload, dict):
                raise ChainError("Invalid chain payload.")
            classification = "public" if kind == "maxwell" else payload.get("classification", "private")
            if classification not in {"public", "private"}:
                raise ChainError("Unknown entry classification.")
            topic = text(record.get("block_type") if kind == "maxwell" else
                         payload.get("topic") or payload.get("type") or "DNA record", "entry type")
        if identifier in seen:
            raise ChainError("Duplicate source identifier.")
        seen.add(identifier)
        entries.append({"id": identifier, "classification": classification, "topic": topic,
                        "message": display_json(payload)})
    label = (f"{kind.upper()} archive: {len(entries)} entries; declared classifications only. "
             "Not public website data. Hashes/signatures/consensus not independently verified.")
    if kind != "research":
        label += " Previous-hash linkage checked only."
    return Source(entries, label)


def load_local(path: Path, demo: bool = False) -> Source:
    data = read_json(path)
    if isinstance(data, dict) and data.get("schema") == "rabbitsoftware.local-public-lookup.v1":
        entries = load_chain(path, demo)
        return Source(entries, "DEMO ONLY: synthetic test records; your real chain is NOT connected." if demo
                      else "LOCAL FILE ONLY: declared public lookup; integrity unverified.", demo)
    if demo:
        raise ChainError("Demo mode requires the packaged synthetic fixture.")
    return adapt(data)


def signed_headers(path: str, credential_path: Path) -> dict[str, str]:
    with credential_path.open("rb") as file:
        raw = file.read(16385)
    if len(raw) > 16384:
        raise ChainError("Credential file exceeds 16 KiB.")
    data = decode(raw)
    if not isinstance(data, dict) or set(data) != {"account", "device", "private_key"}:
        raise ChainError("Credential file needs account, device, and private_key (base64 Ed25519 seed).")
    for field in ("account", "device"):
        if not isinstance(data[field], str) or not re.fullmatch(r"[0-9a-f]{32}", data[field]):
            raise ChainError(f"Invalid credential {field}.")
    try:
        seed = base64.b64decode(data["private_key"], validate=True)
    except (ValueError, TypeError) as error:
        raise ChainError("Invalid base64 device key.") from error
    if len(seed) != 32:
        raise ChainError("Device key must be a 32-byte Ed25519 seed.")
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
    except ImportError as error:
        raise ChainError("Signed reads need cryptography. Run: python -m pip install -r requirements-account.txt") from error
    key = Ed25519PrivateKey.from_private_bytes(seed)
    device = hashlib.sha256(key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)).hexdigest()[:32]
    if device != data["device"]:
        raise ChainError("Device identifier does not match its key; nothing was sent.")
    timestamp = str(int(time.time() * 1000))
    message = f"GET\n{path}\n{timestamp}\n{hashlib.sha256(b'').hexdigest()}".encode()
    return {"X-Account": data["account"], "X-Device": device, "X-Time": timestamp,
            "X-Signature": base64.b64encode(key.sign(message)).decode("ascii")}


def load_account(settings: dict[str, str]) -> Source:
    if "dna" in settings:
        name = settings["dna"]
        if name in {".", ".."} or not re.fullmatch(r"[0-9A-Za-z._-]{1,80}", name):
            raise ChainError("Invalid DNA chain name.")
        path = "/v1/dna/chain/" + name
    else:
        kind, digest = settings.get("snapshot_kind"), settings.get("snapshot", "")
        if kind not in {"research", "maxwell"} or not re.fullmatch(r"[0-9a-f]{64}", digest):
            raise ChainError("Select research/maxwell and a complete snapshot SHA-256.")
        path = f"/v1/{kind}/snapshot/{digest}"
    headers = signed_headers(path, Path(settings["credentials"]))
    raw = fetch(path, headers)
    if "snapshot" in settings and hashlib.sha256(raw).hexdigest() != settings["snapshot"]:
        raise ChainError("Downloaded snapshot checksum does not match.")
    data = decode(raw)
    if "snapshot" in settings and (not isinstance(data, dict) or
                                   ("events" if settings["snapshot_kind"] == "research" else "chain") not in data):
        raise ChainError("Snapshot kind does not match the selected source.")
    if "dna" in settings and (not isinstance(data, dict) or data.get("account") != headers["X-Account"]
                              or data.get("name") != settings["dna"]):
        raise ChainError("Account or chain scope mismatch.")
    source = adapt(data)
    source.label = "SIGNED ACCOUNT READ ONLY. " + source.label
    return source


def load_corpus() -> Source:
    index = decode(fetch("/v1/corpus/batches"))
    names = index.get("batches") if isinstance(index, dict) else None
    if not isinstance(names, list) or len(names) > 50:
        raise ChainError("Invalid public corpus batch index (maximum 50).")
    entries, seen, total_bytes = [], set(), 0
    for name in sorted(names):
        if not isinstance(name, str) or not re.fullmatch(r"[0-9A-Za-z._-]{1,80}", name):
            raise ChainError("Invalid public batch name.")
        raw = fetch("/v1/corpus/batches/" + quote(name, safe=""))
        total_bytes += len(raw)
        if total_bytes > MAX_BYTES:
            raise ChainError("Public corpus exceeds the 1 MiB total limit; use the website search.")
        batch = decode(raw)
        records = batch.get("records") if isinstance(batch, dict) else None
        if not isinstance(records, list):
            raise ChainError("Invalid public corpus batch.")
        for record in records:
            if not isinstance(record, dict):
                raise ChainError("Invalid public research record.")
            identifier = text(record.get("source"), "source") + ":" + text(record.get("external_id"), "source ID")
            if identifier in seen:
                continue
            seen.add(identifier)
            entries.append({"id": identifier, "classification": "public",
                            "topic": text(record.get("title"), "title"), "message": display_json(record)})
            if len(entries) > 1000:
                raise ChainError("Public corpus exceeds 1000 records.")
    return Source(entries, "PUBLIC RESEARCH CORPUS: not a blockchain or your account chain. "
                  "Stable batch/name order; entry numbers may change when batches change.")


def add_arguments(parser) -> None:
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--demo", action="store_true")
    group.add_argument("--chain", type=Path, help="Local lookup, research, Maxwell, or DNA JSON.")
    group.add_argument("--public-corpus", action="store_true", help="Read existing public corpus from sync.")
    group.add_argument("--credentials", type=Path, help="Your registered-device credential file; read-only account access.")
    parser.add_argument("--dna", help="Account-scoped DNA chain name.")
    parser.add_argument("--snapshot-kind", choices=["research", "maxwell"])
    parser.add_argument("--snapshot", help="Full account snapshot SHA-256.")
    parser.add_argument("--remember", action="store_true", help="Save source paths/selection, never key values.")


def settings_from(args, default_demo: bool = False) -> dict:
    if args.dna and (args.snapshot or args.snapshot_kind):
        raise ChainError("Choose DNA or an archive snapshot, not both.")
    if (args.dna or args.snapshot or args.snapshot_kind) and not args.credentials:
        raise ChainError("Account selection requires --credentials.")
    if args.demo:
        settings = {"demo": True}
    elif args.chain:
        settings = {"chain": str(args.chain.resolve())}
    elif args.public_corpus:
        settings = {"public_corpus": True}
    elif args.credentials:
        settings = {"credentials": str(args.credentials.resolve())}
        if args.dna:
            settings["dna"] = args.dna
        else:
            settings.update(snapshot_kind=args.snapshot_kind, snapshot=args.snapshot)
    elif CONFIG.exists():
        settings = read_json(CONFIG)
    elif default_demo:
        settings = {"demo": True}
    else:
        raise ChainError("No source configured. Select --chain PATH, --public-corpus, --demo, or signed account options. "
                         "Add --remember once to reuse that source in bare commands.")
    if not isinstance(settings, dict):
        raise ChainError("Invalid saved connection file.")
    keys = set(settings)
    if keys not in ({"demo"}, {"chain"}, {"public_corpus"}, {"credentials", "dna"},
                    {"credentials", "snapshot_kind", "snapshot"}):
        raise ChainError("Unsupported saved connection fields.")
    if any(not isinstance(value, str) or not value for key, value in settings.items()
           if key not in {"demo", "public_corpus"}) or any(settings[key] is not True for key in keys & {"demo", "public_corpus"}):
        raise ChainError("Invalid saved source selection.")
    return settings


def load_source(settings: dict) -> Source:
    if settings.get("demo"):
        return load_local(DEMO_PATH, True)
    if "chain" in settings:
        return load_local(Path(settings["chain"]))
    if settings.get("public_corpus"):
        return load_corpus()
    return load_account(settings)


def remember(settings: dict) -> None:
    CONFIG.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    temporary = CONFIG.with_suffix(".tmp")
    try:
        with temporary.open("w", encoding="utf-8") as file:
            json.dump(settings, file, indent=2)
        os.chmod(temporary, 0o600)
        temporary.replace(CONFIG)
    finally:
        if temporary.exists():
            temporary.unlink()
