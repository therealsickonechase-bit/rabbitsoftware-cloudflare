RabbitSoftware Read-only CLI 0.2.1
Author: Chase Allen Ringquist

This is a new, read-only lookup tool, not the recovered original application.
Local mode has no network requests. Optional public corpus and signed account
reads contact api.rabbitsoftware.io. No hosted AI, uploads, or chain publication.
Demo records are synthetic. No real RabbitSoftware chain is bundled.

REQUIREMENTS
Python 3.10 or newer. No additional packages are required.
Tested on Windows with Python 3.12.10; macOS/Linux have not been tested.
Get Python from https://www.python.org/downloads/ if needed.

START
1. Extract the entire ZIP. Keep its folders intact.
2. Open a terminal in the extracted folder containing rabbit.py.
3. Run:

python rabbit.py --demo chat
python rabbit.py --demo ask "what's on the chain"
python rabbit.py --demo ask "find BRCA1 on the chain"

On Windows, use "py -3" instead of "python" if that is your Python command.
On macOS/Linux, use "python3" if needed.
This does not install a global "rabbit" command.

Interactive chat supports:
  what's on the chain
  find BRCA1 on the chain
  show entry 1
  exit
It is deterministic lookup, not a free-form AI chatbot.

YOUR LOCAL RECORDS
Use an explicit file:
python rabbit.py --chain "C:\path\to\records.json" ask "find BRCA1 on the chain"
Replace the example with your actual file path.
No file is automatically discovered or modified.
Files are limited to 1 MiB and 1-1000 entries.
The following format remains supported:

{
  "schema": "rabbitsoftware.local-public-lookup.v1",
  "classification": "public",
  "demo": false,
  "entries": [
    {
      "id": "your-entry-id",
      "classification": "public",
      "topic": "Your public topic",
      "message": "Your approved public record text"
    }
  ]
}

Entry IDs must be unique, 1-80 letters/digits/dots/underscores/hyphens.
Fields must be nonempty text, at most 2000 characters, without control characters.
Do not relabel private records as public. Classification is a declaration,
not a complete privacy check. Historical chains, signatures, and block hashes
are not independently verified. Personal genomes/health records do not belong in
the public lookup format. Existing public research/Maxwell v1 archives and
account DNA {name, account, entries} are also readable; private DNA records
stay local and never enter public corpus or research requests. Entry numbers
are one-based positions, not original event IDs or zero-based block indexes.

PUBLIC CORPUS (NOT A BLOCKCHAIN)
python rabbit.py --public-corpus ask "what's on the chain"
This reads the existing public research batches, not your account chain.
No matches is an explicit empty result, not a live provider search.

REUSE A SOURCE FOR THE ORIGINAL COMMANDS
python rabbit.py --chain "C:\path\to\existing-chain.json" --remember ask "show entry 2"
Then:
python rabbit.py ask "what's on the chain"
python rabbit.py ask "show entry 2"
--remember saves paths/selection to ~/.rabbitsoftware/connection.json, not keys
or records. Delete that file to forget. No source means an explicit error.
Source data is reread on each CLI invocation; no silent demo fallback.

SIGNED ACCOUNT READS (OPTIONAL)
python -m pip install -r requirements-account.txt
python rabbit.py --credentials "C:\private\device.json" --dna "your-chain-name" ask "show entry 2"
python rabbit.py --credentials "C:\private\device.json" --snapshot-kind research --snapshot FULL_SHA256 ask "list"
Use your existing registered device, not the Cloudflare dashboard token.
The credential file must contain account and device (32 lowercase hex each),
and private_key (base64 of the 32-byte Ed25519 device seed). Never paste the
file into chat or a website, commit it, or put it in a public folder.
The program checks the derived device ID, signs only read-only GET requests,
refuses redirects, and never transmits the private key. It does not register
devices or bypass signup. Snapshots are checked against their SHA-256, but
event origin signatures, block hashes, and consensus are not verified.
Missing cryptography or missing/invalid credentials fails explicitly.
Protect your credential file with OS permissions; Windows ACLs are not managed.
Real signed account reads require your device file and have not been live-tested.

INTEGRITY AND SAFETY
Download only from https://rabbitsoftware.io/cli.
Compare the ZIP SHA-256 with the checksum published there before extracting.
Windows: Get-FileHash .\rabbitsoftware-cli-0.2.1.zip -Algorithm SHA256
macOS: shasum -a 256 rabbitsoftware-cli-0.2.1.zip
Linux: sha256sum rabbitsoftware-cli-0.2.1.zip
On redirected terminals with a limited character encoding, unsupported source
characters are printed as backslash escapes instead of aborting the lookup.
FILES.sha256 lists the hashes of the unpacked files. Checksums detect changes,
but are not independent signatures or proof of trust if the website is compromised.
Review rabbit.py before running it. Do not paste secrets into your terminal.

LICENSE AND CONTACT
See NOTICE.txt for the UPL-1.0 grant and third-party exclusions.
Website privacy policy: https://rabbitsoftware.io/privacy
Contact: contact@rabbitsoftware.io
No warranty or guarantee of compatibility with historical application records.
