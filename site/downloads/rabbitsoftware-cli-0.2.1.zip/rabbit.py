"""Read-only lookup of an explicitly selected local, public, or signed account source."""

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Sequence

MAX_BYTES = 1024 * 1024
SCHEMA = "rabbitsoftware.local-public-lookup.v1"
DEMO_PATH = Path(__file__).resolve().parent / "tests" / "fixtures" / "demo-chain.json"


class ChainError(ValueError):
    pass


def load_chain(path: Path, demo: bool) -> list[dict[str, str]]:
    with path.open("rb") as source:
        raw = source.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise ChainError("The file exceeds the 1 MiB lookup limit.")
    data = json.loads(raw.decode("utf-8-sig"))
    if not isinstance(data, dict) or set(data) != {"schema", "classification", "demo", "entries"}:
        raise ChainError("Expected a local-public-lookup v1 envelope; historical formats are not yet supported.")
    if data["schema"] != SCHEMA or data["classification"] != "public" or type(data["demo"]) is not bool:
        raise ChainError("Only explicitly public lookup records are supported.")
    if data["demo"] != demo:
        raise ChainError("Demo files require --demo; real records require --chain PATH.")
    entries = data["entries"]
    if not isinstance(entries, list) or not 1 <= len(entries) <= 1000:
        raise ChainError("Provide between 1 and 1000 entries.")
    seen: set[str] = set()
    for entry in entries:
        if not isinstance(entry, dict) or set(entry) != {"id", "classification", "topic", "message"}:
            raise ChainError("Every entry needs id, classification, topic, and message only.")
        if any(not isinstance(value, str) or not value.strip() or len(value) > 2000 for value in entry.values()):
            raise ChainError("Entry fields must be nonempty text of at most 2000 characters.")
        if entry["classification"] != "public" or not re.fullmatch(r"[A-Za-z0-9._-]{1,80}", entry["id"]):
            raise ChainError("An entry is private or has an invalid ID.")
        if entry["id"] in seen:
            raise ChainError("Duplicate entry IDs are not allowed.")
        if any(any(ord(char) < 32 or ord(char) == 127 for char in value) for value in entry.values()):
            raise ChainError("Control characters are not supported in entry text.")
        seen.add(entry["id"])
    return entries


def answer_question(question: str, entries: list[dict[str, str]]) -> str:
    text = question.strip()
    if not text or len(text) > 600:
        raise ChainError("Enter a question of 1 to 600 characters.")
    if text.casefold() in {"what's on the chain", "what is on the chain", "list", "list entries"}:
        selected = entries
    elif match := re.fullmatch(r"(?:find|search)\s+(.+?)(?:\s+on the chain)?", text, re.IGNORECASE):
        term = match[1].strip().casefold()
        selected = [entry for entry in entries if term in f"{entry['topic']} {entry['message']}".casefold()]
    elif match := re.fullmatch(r"show entry\s+(\d+)", text, re.IGNORECASE):
        number = int(match[1])
        if not 1 <= number <= len(entries):
            raise ChainError(f"Entry number must be between 1 and {len(entries)}.")
        selected = [entries[number - 1]]
    else:
        raise ChainError('Supported questions: "what\'s on the chain", "find BRCA1 on the chain", or "show entry 1".')
    if not selected:
        return "No matching entries in the selected source."
    return "\n\n".join(
        f"Entry {entries.index(entry) + 1} [{entry['id']}] ({entry['classification']})\n{entry['topic']}\n{entry['message']}"
        for entry in selected
    )


def main(argv: Sequence[str] | None = None) -> int:
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(errors="backslashreplace")
    from chain_access import add_arguments, load_source, remember, settings_from
    parser = argparse.ArgumentParser(description=__doc__)
    add_arguments(parser)
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("chat", help="Interactive deterministic chain lookup, not an AI model.")
    ask = commands.add_parser("ask", help="Ask a supported chain lookup question.")
    ask.add_argument("question")
    args = parser.parse_args(argv)
    try:
        settings = settings_from(args)
        selected = load_source(settings)
        entries = selected.entries
        if args.remember:
            remember(settings)
        print(selected.label)
        print("Read-only lookup. No AI requests, uploads, or chain publication.")
        if args.command == "ask":
            print(answer_question(args.question, entries))
            return 0
        print('Ask a chain question, or type "exit".')
        while True:
            try:
                question = input("rabbit> ")
            except EOFError:
                return 0
            if question.strip().casefold() in {"exit", "quit"}:
                return 0
            try:
                print(answer_question(question, entries))
            except ChainError as error:
                print(f"Error: {error}", file=sys.stderr)
    except (OSError, UnicodeError, ValueError, RecursionError) as error:
        print(f"Error: {error}. Check the selected file and format; no data was uploaded.", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nLookup cancelled.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
