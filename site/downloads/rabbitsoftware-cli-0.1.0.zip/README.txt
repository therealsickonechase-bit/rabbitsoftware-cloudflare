RabbitSoftware Offline CLI 0.1.0
Author: Chase Allen Ringquist

This is a new, read-only lookup tool, not the recovered original application.
No network requests, hosted AI, account login, or chain publication.
Demo records are synthetic. No real RabbitSoftware chain is bundled.

REQUIREMENTS
Python 3.10 or newer. No additional packages are required.
Tested on Windows with Python 3.12.10; macOS/Linux have not been tested.
Get Python from https://www.python.org/downloads/ if needed.

START
1. Extract the entire ZIP. Keep its folders intact.
2. Open a terminal in the extracted folder containing rabbit.py.
3. Run:

python rabbit.py --demo chat
python rabbit.py --demo ask "what's on the chain"
python rabbit.py --demo ask "find BRCA1 on the chain"

On Windows, use "py -3" instead of "python" if that is your Python command.
On macOS/Linux, use "python3" if needed.
This does not install a global "rabbit" command.

Interactive chat supports:
  what's on the chain
  find BRCA1 on the chain
  show entry 1
  exit
It is deterministic lookup, not a free-form AI chatbot.

YOUR LOCAL RECORDS
Use an explicit file:
python rabbit.py --chain "C:\path\to\records.json" ask "find BRCA1 on the chain"
Replace the example with your actual file path.
No file is automatically discovered or modified.
Files are limited to 1 MiB and 1-1000 entries.
Only the following new format is supported:

{
  "schema": "rabbitsoftware.local-public-lookup.v1",
  "classification": "public",
  "demo": false,
  "entries": [
    {
      "id": "your-entry-id",
      "classification": "public",
      "topic": "Your public topic",
      "message": "Your approved public record text"
    }
  ]
}

Entry IDs must be unique, 1-80 letters/digits/dots/underscores/hyphens.
Fields must be nonempty text, at most 2000 characters, without control characters.
Do not relabel private records as public. Classification is a declaration,
not a complete privacy check. Historical chains, signatures, and block hashes
are not supported or verified. Personal genomes/health records do not belong here.
Original commands without --demo or --chain fail rather than use fake real data.

INTEGRITY AND SAFETY
Download only from https://rabbitsoftware.io/cli.
Compare the ZIP SHA-256 with the checksum published there before extracting.
Windows: Get-FileHash .\rabbitsoftware-cli-0.1.0.zip -Algorithm SHA256
macOS: shasum -a 256 rabbitsoftware-cli-0.1.0.zip
Linux: sha256sum rabbitsoftware-cli-0.1.0.zip
FILES.sha256 lists the hashes of the unpacked files. Checksums detect changes,
but are not independent signatures or proof of trust if the website is compromised.
Review rabbit.py before running it. Do not paste secrets into your terminal.

LICENSE AND CONTACT
See NOTICE.txt for the UPL-1.0 grant and third-party exclusions.
Website privacy policy: https://rabbitsoftware.io/privacy
Contact: contact@rabbitsoftware.io
No warranty or guarantee of compatibility with historical application records.
